package main.java.org.opcode.Instructions;

public interface Instruction {
     void execute();
//     boolean validation();
}
