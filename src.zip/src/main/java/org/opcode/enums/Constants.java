package main.java.org.opcode.enums;

public class Constants {

    public final static String SET="SET";
    public final static String MOVE="MOVE";
    public final static String DEC="DEC";
    public final static String INC="INC";
    public final static String ADR="ADDR";
    public final static String ADD="SUB";
    public final static String RST="RST";

}
